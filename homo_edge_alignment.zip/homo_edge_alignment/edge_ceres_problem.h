
// ceres
#include <iostream>

#include <ceres/ceres.h>
#include <ceres/rotation.h>
#include <ceres/cubic_interpolation.h>
#include <ceres/loss_function.h>

using namespace std;

template <typename T>
Eigen::Matrix<T, 2, 2> RotationMatrix2D(T yaw_radians) {
  const T cos_yaw = ceres::cos(yaw_radians);
  const T sin_yaw = ceres::sin(yaw_radians);
  Eigen::Matrix<T, 2, 2> rotation;
  rotation << cos_yaw, -sin_yaw, sin_yaw, cos_yaw;
  return rotation;
}

// Normalizes the angle in radians between [-pi and pi).
template <typename T>
inline T NormalizeAngle(const T& angle_radians) {
  // Use ceres::floor because it is specialized for double and Jet types.
  T two_pi(2.0 * M_PI);
  return angle_radians -
      two_pi * ceres::floor((angle_radians + T(M_PI)) / two_pi);
}

// Defines a local parameterization for updating the angle to be constrained in
// [-pi to pi).
class AngleLocalParameterization {
 public:
  template <typename T>
  bool operator()(const T* theta_radians, const T* delta_theta_radians,
                  T* theta_radians_plus_delta) const {
    *theta_radians_plus_delta =
        NormalizeAngle(*theta_radians + *delta_theta_radians);
    return true;
  }

  static ceres::LocalParameterization* Create() {
    return (new ceres::AutoDiffLocalParameterization<AngleLocalParameterization,
                                                     1, 1>);
  }
};


class EdgeAlignResidual {
public:
    EdgeAlignResidual(
        const Eigen::Vector2d& point,
        const ceres::BiCubicInterpolator<ceres::Grid2D<double,1>>& interpolated_a
    ): src_point(point), interp_dt(interpolated_a)
    {
    }

    template <typename T>
    bool operator()( const T* h, T* residue ) const { // 自动求导，不能和解析求导的Evaluate()函数共存？
        // b_quat_a, b_t_a to b_T_a
        Eigen::Matrix<T, 3, 3> H;
        H << h[0], h[1], h[2],
             h[3], h[4], h[5],
             h[6], h[7], h[8];

        Eigen::Matrix<T, 3, 1> src_p;
        src_p << T(src_point(0)), T(src_point(1)), T(1.);
        // cout<<"src_p:\n"<<src_p<<endl;
        // cout<<"src_p(2):\n"<<src_p(2)<<endl;
        Eigen::Matrix<T, 3, 1> tar_point = H * src_p;
        // cout<<"tar_point:\n "<<double(tar_point(0))<<", "<<double(tar_point(1))<<", "<<double(tar_point(2))<<endl;
        // cout<<"tar_point:\n"<<tar_point(0)<<", "<<tar_point(1)<<", "<<tar_point(2)<<endl;
        // cout<<"tar_point:\n"<<tar_point<<endl;
        // cout<<"tar_pont(2):\n"<<tar_point(2)<<endl;
        if(tar_point(2)==T(0.)){
            return false;
        }
        tar_point /= tar_point(2);
        // 在 DT图像中， 查询得到残差值
        // interp_dt.Evaluate( tar_point(0), tar_point(1), &residue[0] ); 
        interp_dt.Evaluate( tar_point(1), tar_point(0), &residue[0] ); 
        return true;
    }

    static ceres::CostFunction *Create(
        const Eigen::Vector2d& point,
        const ceres::BiCubicInterpolator<ceres::Grid2D<double, 1>> &interpolated_a)
    {
        return( new ceres::AutoDiffCostFunction<EdgeAlignResidual,1,9>
            (
                new EdgeAlignResidual( point,  interpolated_a)
            )
            );
    }

private:

    const Eigen::Vector2d src_point; // translation
    const ceres::BiCubicInterpolator<ceres::Grid2D<double,1>>& interp_dt; // 插值的DT图像

};
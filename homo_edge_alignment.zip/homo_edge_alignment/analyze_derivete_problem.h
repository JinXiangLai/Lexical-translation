
// ceres
#include <iostream>

#include <ceres/ceres.h>
#include <ceres/loss_function.h>

using namespace std;

constexpr double kXDiff = 5.;
constexpr double kYDiff = 5.;

double binary_interpolation(const double x, const double y, const Eigen::MatrixXd &img)
{
    int x1 = int(x);
    //int x2 = int(x + 0.5);
    int x2 = int(x) + 1;
    int y1 = int(y);
    //int y2 = int(y + 0.5);
    int y2 = int(y) + 1;

    double gap_x = x - x1;
    double gap_y = y - y1;
    double res =
        img(y1, x1) * (1. - gap_x) * (1. - gap_y) +
        img(y1, x2) * gap_x * (1. - gap_y) +
        img(y2, x1) * (1. - gap_x) * gap_y +
        img(y2, x2) * gap_x * gap_y;
    return res;
}

class EdgeAlignResidual : public ceres::SizedCostFunction<1,8>{
public:
    EdgeAlignResidual(const Eigen::Vector2d &src_point,
                      const Eigen::MatrixXd *x_diff, const Eigen::MatrixXd *y_diff,
                      const Eigen::MatrixXd *e_dist)
        : src_point_(src_point),
          x_diff_(x_diff),
          y_diff_(y_diff),
          e_dist_(e_dist) {}

    virtual bool Evaluate(double const *const *parameters, double *residuals,
                          double **jacobians) const {
        double const *const * h = parameters;
        Eigen::Matrix<double, 3, 3> H;
        H << h[0][0], h[0][1], h[0][2],
             h[0][3], h[0][4], h[0][5],
             h[0][6], h[0][7], 1.;
        //cout<<"HE:\n"<<H<<endl;
        Eigen::Matrix<double, 3, 1> src;
        src << (src_point_(0)), (src_point_(1)), (1.);

        Eigen::Matrix<double, 3, 1> tar = H * src;
        // static int count = 0;
        // ++count;
        //cout<<"tar:\n"<<tar<<endl;
        // if(tar(2)==(0.)){
        //     residuals[0] = 1e-9;
        //     for(int i=0; i<9; ++i)
        //         jacobians[0][i] = 1;
        //     cout<<"count3 = "<<count<<endl;
        //     return true;
        //     //return false;
        // }

        // tar_point /= tar_point(2);
        
        // double* jacobian = jacobians[0];
        // if (!jacobian) return true;

        double x = tar(0)/tar(2);
        double y = tar(1)/tar(2);
        const int rows = e_dist_->rows() - kYDiff;
        const int cols = e_dist_->cols() - kYDiff;
        if(x<kXDiff || x>cols || y<kYDiff || y>rows){
            residuals[0] = 0.;
            // if (!jacobians){

            // }else{
            //     for(int i=0; i<8; ++i)
            //         jacobians[0][i] = 0.;
            // }
            // return true;

        }else{
            residuals[0] = binary_interpolation(x, y, *e_dist_);
        }
        if (!jacobians) return true;
        double* jacobian = jacobians[0];
        // if (!jacobian) return true;


        
        //     residuals[0] = 0.;
        //     for(int i=0; i<9; ++i)
        //         jacobian[i] = 0.;
        //     //cout<<"count4 = "<<count<<endl;
        //     //jacobians = nullptr;
        //     return true;
        //     //return false; // get error
        // }
        //cout<<"x, y = "<<x<<", "<<y<<endl;
        /** calculate dtx/dh_i, dty/d_hi **/
        // t = h[6]*src(0) + h[7]*src(1) + h[8] = tar(2)
        // derivation of 1/t = -1/(t*t)
        double t_square = tar(2) * tar(2);
        //cout<<"t_square = "<<t_square<<endl;

        double dtx_h0 = src(0)/tar(2);
        double dtx_h1 = src(1)/tar(2);
        double dtx_h2 = 1./tar(2);
        // dtx_h3, dtx_h4, dtx_h5 = 0
        double dtx_h6 = -1. * tar(0) /t_square * src(0);
        double dtx_h7 = -1. * tar(0) /t_square * src(1);
        // double dtx_h8 = -1. * tar(0) /t_square * 1.;

        // dty_h0, dty_h1, dty_h2 = 0
        double dty_h3 = src(0)/tar(2);
        double dty_h4 = src(1)/tar(2);
        double dty_h5 = 1./tar(2);
        double dty_h6 = -1. * tar(1) /t_square * src(0);
        double dty_h7 = -1. * tar(1) /t_square * src(1);
        // double dty_h8 = -1. * tar(1) /t_square * 1.;

        /***********
         * calculate df/dh_i also jacobian
         * df/dh_i = df/dx * dx/dh_i + df/dy * dy/dh_i
        ***********/
        double df_dx = binary_interpolation(x, y, *x_diff_);
        double df_dy = binary_interpolation(x, y, *y_diff_);
        // if(df_dx==0||df_dy==0) {
        //     for(int i=0; i<9; ++i)
        //         jacobian[i] = 0.;
        //     return true;
        // }
        //cout<<"get res"<<endl;
        jacobian[0] = df_dx * dtx_h0;
        jacobian[1] = df_dx * dtx_h1;
        jacobian[2] = df_dx * dtx_h2;
        jacobian[3] = df_dy * dty_h3;
        jacobian[4] = df_dy * dty_h4;
        jacobian[5] = df_dy * dty_h5;
        //jacobian[6] = 0;//df_dx * dtx_h6 + df_dy * dty_h6;
        //jacobian[7] = 0;//df_dx * dtx_h7 + df_dy * dty_h7;
        //jacobian[8] = 0;//df_dx * dtx_h8 + df_dy * dty_h8;
        jacobian[6] = df_dx * dtx_h6 + df_dy * dty_h6;
        jacobian[7] = df_dx * dtx_h7 + df_dy * dty_h7;
        // jacobian[8] = df_dx * dtx_h8 + df_dy * dty_h8;
        //cout<<"return true"<<endl;
        //cout<<"count2 = "<<count<<endl;
        // cout<<"x, y: "<<x<<" "<<y<<endl;
        // for(int i=0; i<9; ++i){
        //     cout<<jacobian[i]<<" ";
        // }
        // cout<<endl;
        // cout<<"residual = "<<residuals[0]<<endl;
        return true;
    } // count0 = 3768

private:
    const Eigen::Vector2d src_point_; // translation
    // const ceres::BiCubicInterpolator<ceres::Grid2D<double,1>>& interp_dt; // 插值的DT图像
    const Eigen::MatrixXd* x_diff_;
    const Eigen::MatrixXd* y_diff_;
    const Eigen::MatrixXd* e_dist_;
};
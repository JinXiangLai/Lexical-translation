#include <iostream>
#include <string>
#include <cmath>

#include <Eigen/Core>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/eigen.hpp>
#include <opencv2/highgui.hpp>

#include "edge_ceres_problem.h"

using namespace std;
using namespace cv;

// 定义一些超参数
constexpr double InputCannyEdgeTh1 = 110.;
constexpr double InputCannyEdgeTh2 = 80.;
const double Degree2Radian = acos(-1.)/180;

// 提取一帧图像的canny边缘
void ExtractCannyEdge(const Mat &src, Mat *canny_out);

// 计算 source帧的距离变换(DT) 以及对应的梯度导数
void CalculateEdgeOptimizationStructure(const Mat &canny_img, Mat *dt, Eigen::Vector3f *opt_structure);

void CalculateDistanceTransform(const Mat& canny, Mat* dt);

// 根据计算得到的Canny边缘，优化数据结构来对 src图像到tar图像的运动变换进行估计
bool TrackImage(const Mat& src, const Mat& tar, Eigen::Matrix3d init_transform, Eigen::Matrix3d* final_guess);

void transform_debug(const Mat& src_canny, Eigen::Matrix3d& transform, Mat* tar);

void merge_image(const Mat& src, const Mat& tar, const Eigen::Matrix3d& transform, Mat* merge_img);

void create_homography(double* data, Eigen::Matrix3d* homo);

void homography_debug(const Mat& src_canny, const Eigen::Matrix3d& homo, Mat* tar);

void ExtractCannyEdge(const Mat &src, Mat *canny_out)
{
    Mat gray;
    cv::cvtColor(src, gray, COLOR_BGR2GRAY);

    // Edge detection
    const int ksize = 5;
    Mat gray_blur;
    cv::GaussianBlur(gray, gray_blur, cv::Size(ksize, ksize), 3);
    cv::imshow("blur", gray_blur);
    // blur again 
    // cv::GaussianBlur(gray_blur, gray_blur, cv::Size(ksize, ksize), 3);
    cv::Canny(gray_blur, *canny_out, InputCannyEdgeTh1, InputCannyEdgeTh2, 3,
              true);
    cv::imshow("canny", *canny_out);
    return;
}

void CalculateEdgeOptimizationStructure(const Mat &canny_img, Mat *dt,
                                        Eigen::Vector3f *opt_structure)
{
    const int width = canny_img.cols;
    const int height = canny_img.rows;

    // Attention dt的数据类型必须是float类型
    cv::distanceTransform(255 - canny_img, *dt, DIST_L2, DIST_MASK_PRECISE);
    if (dt->type() != CV_32F)
    {
        cout << "\n******\nError: dt->type() = " << dt->type() << "\n******\n"
             << endl;
    }

    opt_structure =
        (reinterpret_cast<Eigen::Vector3f *>(Eigen::internal::aligned_malloc(
            width * height * sizeof(Eigen::Vector3f))));
    const float *dt_data = reinterpret_cast<float *>(dt->data);
    // Fill the first level of the optimization structure with the DT
    for (int idx = 0; idx < width * height; ++idx)
        opt_structure[idx][0] = dt_data[idx];
    // 计算 梯度dx, dy，其中首、末（行、列均不被处理）
    for (int idx = width; idx < width * (height - 1); ++idx)
    {
        // Note: The gradient is inverted compared to photometric approaches!
        // 注意，这里计算的是DT图像的梯度，和导数有关，与光度梯度无关，我们是使用边缘做SLAM
        opt_structure[idx][1] =
            (opt_structure[idx - 1][0] - opt_structure[idx + 1][0]) * 0.5f; // dx
        opt_structure[idx][2] =
            (opt_structure[idx - width][0] - opt_structure[idx + width][0]) *
            0.5f; // dy
    }
    return;
}

void CalculateDistanceTransform(const Mat& canny_img, Mat* dt){
    cv::distanceTransform(255 - canny_img, *dt, DIST_L2, DIST_MASK_PRECISE);
    return;
}


bool TrackImage(const Mat& src, const Mat& tar, Eigen::Matrix3d init_transform, Eigen::Matrix3d* final_guess){
    
    
    const int width = src.cols;
    const int height = src.rows;

    // 提取 canny边缘
    Mat tar_canny, src_canny;
    ExtractCannyEdge(tar, &tar_canny);
    ExtractCannyEdge(src, &src_canny);

    // just for debug
    // cv::imshow("src-canny", src_canny);
    // cv::imshow("tar-canny", tar_canny);
    // cv::waitKey(0);
    
    // 计算tar图像的dt
    Mat tar_dt;
    CalculateDistanceTransform(tar_canny, &tar_dt);
    Eigen::MatrixXd e_disTrans;
    cv::cv2eigen( tar_dt, e_disTrans );
    cout<<"tar_dt, e_disTrans size = "<<tar_dt.rows<<" "<<tar_dt.cols<<" "<<e_disTrans.rows()<<" "<<e_disTrans.cols()<<endl;
    ceres::Grid2D<double,1> grid(e_disTrans.data(), 0, e_disTrans.rows(), 0, e_disTrans.cols());
    ceres::BiCubicInterpolator< ceres::Grid2D<double,1> > interpolated_disTrans( grid );

    // Initial pose guess, 这个初始估计我们可以根据在线定位的结果给出优化
    double homo[9] = {     0.999999,  0.000967057,    0.0347977,
-0.000963934 ,     0.99999 ,     168.052,
           0 ,           0,            1 };

    Eigen::Matrix3d init_guess = Eigen::Matrix3d::Identity();
    create_homography(homo, &init_guess);

    Mat init_tar_img = tar.clone();

    // transform_debug(src_canny, init_guess, &init_tar_img);
    homography_debug(src_canny, init_guess, &init_tar_img);
    cv::imshow("init_tar_reproject", init_tar_img);
    Mat init_merge_img;
    merge_image(src, tar, init_guess, &init_merge_img);
    cv::imshow("init merge result", init_merge_img);
    // Lastly, we use a local parameterization to normalize the orientation in the range which is normalized between【-pi,pi)
    ceres::LocalParameterization* angle_local_parameterization = AngleLocalParameterization::Create();

    // 使用ceres构建最小二乘函数
    ceres::Problem problem;
    for( int j=0; j<width; ++j){
        for( int i=0; i<height; ++i ){
            // 只考虑对canny边缘进行投影
            if( src_canny.at<uchar>(i, j) == 0 ){
                continue;
            }
            // const Eigen::Vector2d p(double(j), double(i));
            Eigen::Vector2d p;
            p << double(j), double(i);
            ceres::CostFunction * cost_function = EdgeAlignResidual::Create( p, interpolated_disTrans );
            problem.AddResidualBlock( cost_function, new ceres::CauchyLoss(1.0), homo );
            // problem.SetParameterization(&yaw, angle_local_parameterization);
        }
    }

    // Run
    ceres::Solver::Options options;
    options.minimizer_progress_to_stdout = false; //true;
    options.linear_solver_type = ceres::SPARSE_SCHUR; //试试稀疏求解，之前是DENSE求解导致很慢
    options.num_threads = 1;
    options.max_num_iterations = 50;
    ceres::Solver::Summary summary;
    options.function_tolerance = 1e-20;
    options.parameter_tolerance = 1e-20;
    options.trust_region_strategy_type = ceres::LEVENBERG_MARQUARDT;
    options.min_line_search_step_size = 1e-3;
    ceres::Solve( options, &problem, &summary );
    // cout<<summary.BriefReport()<<endl;

    create_homography(homo, final_guess);
    cout<<"final guess transform:\n"<<*final_guess<<endl;

    Mat tar_img = tar.clone();

    // transform_debug(src_canny, *final_guess, &tar_img);
    homography_debug(src_canny, *final_guess, &tar_img);

    cv::imshow("tar_reproject", tar_img);
    imwrite("./tar_reproject0.png", tar_img);
    Mat merge_img;
    merge_image(src, tar, *final_guess, &merge_img);
    cv::imshow("merge result", merge_img);
    cv::waitKey(0);

    return true;
}

bool pocess_image(int num){
    // const string main_path = "/home/jinxianglai/aw_docker/debug_back_ground/";
    // const string main_path = "/home/jinxianglai/Downloads/";
    // const string main_path = "/home/jinxianglai/edge_alignment/";
    // const string main_path = "/home/jinxianglai/aw_docker/orb_feature_orbslam2_jinghuan_only_localize/";
    const string main_path = "/home/jinxianglai/homo_edge_alignment/";
    string name1 = "gp"+to_string(num);
    string name2 = "gc"+to_string(num);
    cout<<"num = "<<num<<endl;
    //-- 读取图像
    Mat img_1 = imread ( main_path+name1+".png", cv::ImreadModes::IMREAD_COLOR );
    Mat img_2 = imread ( main_path+name2+".png", cv::ImreadModes::IMREAD_COLOR );

    Eigen::Matrix3d init_guess = Eigen::Matrix3d::Identity();
    Eigen::Matrix3d final_guess = Eigen::Matrix3d::Identity();
    if(TrackImage(img_1, img_2, init_guess, &final_guess)){
        // return true;
        cout<<"track successfully.\n";
    }else{
        return false;
    }

    // int width = 960;
    // int height = 540;

    // Mat T_t_s, imageTransform1;
    // cv::eigen2cv(final_guess, T_t_s);
    // warpPerspective(img_1, imageTransform1, T_t_s, Size(width, height));
    // imshow("仿射变换后图像", imageTransform1);

    // Mat dst(height, width,CV_8UC3);
    // imageTransform1.copyTo(dst(Rect(0, 0, imageTransform1.cols, imageTransform1.rows)));
    // img_2.copyTo(dst(Rect(0, 0, img_2.cols, img_2.rows)));
    // imshow("b_dst", dst);
    // cv::waitKey(0);
    return true;
}

void transform_debug(const Mat& src_canny, Eigen::Matrix3d& transform, Mat* tar){
    const int w = src_canny.cols;
    const int h = src_canny.rows;
    const Eigen::Matrix2d R = transform.block<2,2>(0,0);
    const Eigen::Vector2d t = transform.block<2,1>(0,2);
    Mat& tar_img = *tar;
    for(int j=0; j<w; ++j){
        for(int i=0; i<h; ++i){
            if( src_canny.at<uchar>(i, j) == 0 ){
                continue;
            }
            Eigen::Vector2d p;
            p << double(j), double(i);
            const Eigen::Vector2d tar_p = R * p + t;
            const int x = int(tar_p(0));
            const int y = int(tar_p(1));
            if( x>=0 && x<tar_img.cols && y>=0 && y<tar_img.rows){
                tar_img.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 0, 255);
            } 
        }
    }
    return;
}

void homography_debug(const Mat& src_canny, const Eigen::Matrix3d& homo, Mat* tar){
    const int w = src_canny.cols;
    const int h = src_canny.rows;
    Mat& tar_img = *tar;
    for(int j=0; j<w; ++j){
        for(int i=0; i<h; ++i){
            if( src_canny.at<uchar>(i, j) == 0 ){
                continue;
            }
            Eigen::Vector3d p;
            p << double(j), double(i), 1.;
            Eigen::Vector3d tar_p = homo * p;
            tar_p /= tar_p(2);
            const int x = int(tar_p(0));
            const int y = int(tar_p(1));
            if( x>=0 && x<tar_img.cols && y>=0 && y<tar_img.rows){
                tar_img.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 0, 255);
            } 
        }
    }
    return;
}

void merge_image(const Mat& src, const Mat& tar, const Eigen::Matrix3d& transform, Mat* merge_img){
    Mat H;
    eigen2cv(transform, H);
    warpPerspective(src, *merge_img, H, Size(src.cols + 300, src.rows + 300));
    tar.copyTo((*merge_img)(Rect(0, 0, tar.cols, tar.rows)));
}

void create_homography(double* data, Eigen::Matrix3d* homo){
    *homo << data[0], data[1], data[2],
             data[3], data[4], data[5],
             data[6], data[7], data[8];
}

int main(){
    int num = 188;
    while(1){
        pocess_image(num++);
        break;
    }
    return 0;
}
